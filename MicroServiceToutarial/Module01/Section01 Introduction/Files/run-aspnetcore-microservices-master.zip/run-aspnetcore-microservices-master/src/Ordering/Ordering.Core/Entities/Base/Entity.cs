﻿namespace Ordering.Core.Entities.Base
{
    public abstract class Entity : EntityBase<int>
    {
    }
}
