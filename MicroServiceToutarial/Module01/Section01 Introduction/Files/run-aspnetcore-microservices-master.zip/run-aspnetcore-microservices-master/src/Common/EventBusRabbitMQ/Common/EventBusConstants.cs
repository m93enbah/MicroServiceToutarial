﻿namespace EventBusRabbitMQ.Common
{
    public static class EventBusConstants
    {
        public const string BasketCheckoutQueue = "basketCheckoutQueue";
    }
}
